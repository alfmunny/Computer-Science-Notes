#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
	/* cast to void to suppress compiler warnings about unused variables */
	(void)argc;
	(void)argv;

	printf("Hello, World!\n");
	exit(EXIT_SUCCESS);
}
