#ifndef _GETINPUT_H
#define _GETINPUT_H

char *getinput(char *, size_t);

#endif
