#ifndef _SIG_H
#define _SIG_H

void sig_int(int);

#endif
