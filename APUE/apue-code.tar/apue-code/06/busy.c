int main() {
	int n;
	while(1) {
		n++;
	}
	return n;
}
